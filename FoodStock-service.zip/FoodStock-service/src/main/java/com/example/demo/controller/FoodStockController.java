package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.entity.FoodStock;
import com.example.demo.service.FoodStockService;



@RestController
@RequestMapping("/food-stock")
public class FoodStockController {
	
	@Autowired
	private FoodStockService foodStockService;
	
	@GetMapping("/food-stocks")
	public List<FoodStock> getFoodStocks() {
		
		return foodStockService.getFoodStocks();
	}
	
	@GetMapping("/food-stock/{id}")
	public FoodStock getFoodStock(@PathVariable long id) {
		
		return foodStockService.getSingleFoodStock(id);
	}
	
	
	@PostMapping("/save")
	public FoodStock saveSeeker(@RequestBody FoodStock foodStock) {
		
		return foodStockService.saveFoodStock(foodStock);
		
	}
	//update
	@PutMapping("/update/{id}")
	public FoodStock updateFoodStock(@PathVariable long id, @RequestBody FoodStock foodStock) {
		
		foodStock.setFoodStockId(id);
		return foodStockService.updateFoodStock(foodStock);
		
	}
	
	@DeleteMapping("/delete/{id}")
	public void deleteFoodStock(@PathVariable long id) {
		
		foodStockService.deleteFoodStock(id);
		
		
	}

}