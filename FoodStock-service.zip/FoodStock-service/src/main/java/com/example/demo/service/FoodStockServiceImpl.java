package com.example.demo.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entity.FoodStock;
import com.example.demo.repository.FoodStockRepo;



@Service
public class FoodStockServiceImpl implements FoodStockService{
	
	@Autowired
	private FoodStockRepo foodStockRepo;

	@Override
	public List<FoodStock> getFoodStocks() {
		// TODO Auto-generated method stub
		return foodStockRepo.findAll();
	}

	@Override
	public FoodStock saveFoodStock(FoodStock foodStock) {
		// TODO Auto-generated method stub
		return foodStockRepo.save(foodStock);
	}

	@Override
	public FoodStock getSingleFoodStock(long id) {
		// TODO Auto-generated method stub
		Optional<FoodStock> foodStock = foodStockRepo.findById(id);
		
		if(foodStock.isPresent()) {
			return foodStock.get();
		}
		throw new RuntimeException("Food Stock is not found with the ID " + id);
	}

	@Override
	public void deleteFoodStock(long id) {
		// TODO Auto-generated method stub
		foodStockRepo.deleteById(id);
	}

	@Override
	public FoodStock updateFoodStock(FoodStock foodStock) {
		// TODO Auto-generated method stub
		return foodStockRepo.save(foodStock);
	}

}