package com.example.demo.service;

import java.util.List;

import com.example.demo.entity.FoodStock;





public interface FoodStockService {
	
	List<FoodStock> getFoodStocks();
	
	FoodStock saveFoodStock(FoodStock foodStock);
		
	FoodStock getSingleFoodStock(long id);
		
	void deleteFoodStock(long id);
		
	FoodStock updateFoodStock(FoodStock foodStock);

}

