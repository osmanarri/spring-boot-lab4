package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.entity.FoodBank;
import com.example.demo.service.FoodBankService;




@RestController
@RequestMapping("/food-bank")
public class FoodBankController {
	
	@Autowired
	private FoodBankService fService;
	
	@GetMapping("/food-banks")
	public List<FoodBank> getFoodBanks() {
		
		return fService.getFoodBanks();
	}
	
	@GetMapping("/food-bank/{id}")
	public FoodBank getSeeker(@PathVariable long id) {
		
		return fService.getSingleFoodBank(id);
	}
	
	
	@PostMapping("/save")
	public FoodBank saveSeeker(@RequestBody FoodBank foodBank) {
		
		return fService.saveFoodBank(foodBank);
		
	}
	//update
	@PutMapping("/update/{id}")
	public FoodBank updateFoodBank(@PathVariable long id, @RequestBody FoodBank foodBank) {
		
		foodBank.setFoodBankId(id);
		return fService.updateFoodBank(foodBank);
		
	}
	
	@DeleteMapping("/delete/{id}")
	public void deletefoodBank(@PathVariable long id) {
		
		fService.deleteFoodBank(id);
		
		
	}

}
