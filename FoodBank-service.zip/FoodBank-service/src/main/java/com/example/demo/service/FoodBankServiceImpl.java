package com.example.demo.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.example.demo.entity.FoodBank;
import com.example.demo.repository.FoodBankRepo;





@Service
public class FoodBankServiceImpl implements FoodBankService{

	@Autowired
	private FoodBankRepo foodBankRepo;
	

	
	
	@Override
	public List<FoodBank> getFoodBanks() {
		// TODO Auto-generated method stub
		return foodBankRepo.findAll();
	}

	@Override
	public FoodBank saveFoodBank(FoodBank foodBank) {
		// TODO Auto-generated method stub
		return foodBankRepo.save(foodBank);
	}

	@Override
	public FoodBank getSingleFoodBank(long id) {
		// TODO Auto-generated method stub
		Optional<FoodBank> foodBank = foodBankRepo.findById(id);
		
		if(foodBank.isPresent()) {
			return foodBank.get();
		}
		throw new RuntimeException("Food Bank is not found with the ID " + id);
	}

	@Override
	public void deleteFoodBank(long id) {
		// TODO Auto-generated method stub
		
		foodBankRepo.deleteById(id);
		
	}

	@Override
	public FoodBank updateFoodBank(FoodBank foodBank) {
		// TODO Auto-generated method stub
		return foodBankRepo.save(foodBank);
	}

}
