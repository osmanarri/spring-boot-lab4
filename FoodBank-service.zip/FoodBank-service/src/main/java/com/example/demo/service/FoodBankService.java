package com.example.demo.service;

import java.util.List;

import com.example.demo.entity.FoodBank;



public interface FoodBankService {
	
   List<FoodBank> getFoodBanks();
	
   FoodBank saveFoodBank(FoodBank foodBank);
	
   FoodBank getSingleFoodBank(long id);
	
	void deleteFoodBank(long id);
	
	FoodBank updateFoodBank(FoodBank foodBank);

}

