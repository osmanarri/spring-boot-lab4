package com.example.demo.service;


import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.example.demo.VO.FoodBank;
import com.example.demo.VO.ResponseTemplateVO;
import com.example.demo.entity.Seeker;
import com.example.demo.repository.SeekerRepo;



@Service
public class SeekerServiceImpl implements SeekerService{
	
	@Autowired
	private SeekerRepo seekerRepo;
	
	@Autowired
	private RestTemplate restTemplate;

	@Override
	public List<Seeker> getSeekers() {
		
		return seekerRepo.findAll();
	}

	@Override
	public Seeker saveSeeker(Seeker seeker) {
		
		return seekerRepo.save(seeker);
	}

	@Override
	public Seeker getSingleSeeker(long id) {
		
		Optional<Seeker> seeker = seekerRepo.findById(id);
		
		if(seeker.isPresent()) {
			return seeker.get();
		}
		throw new RuntimeException("Seeker is not found with the ID " + id);
	}

	@Override
	public void deleteSeeker(long id) {

		seekerRepo.deleteById(id);
	}

	@Override
	public Seeker updateSeeker(Seeker seeker) {
		
		return seekerRepo.save(seeker);
	}

	@Override
	public ResponseTemplateVO getSeekerWithFoodBank(Long seekerId) {
		
		ResponseTemplateVO vo =new ResponseTemplateVO();
		Seeker seeker = seekerRepo.findBySeekerId(seekerId);
		
		FoodBank foodBank = 
				restTemplate.getForObject("http://localhost:9001/food-bank/food-bank/" + seeker.getFoodBankId(),
						FoodBank.class);
		
		vo.setSeeker(seeker);
		vo.setFoodBank(foodBank);
		
		return vo;
		
		
	}

}

