package com.example.demo.VO;

import com.example.demo.entity.Seeker;

public class ResponseTemplateVO {
	
	private FoodBank foodBank;
	private Seeker seeker;
	public FoodBank getFoodBank() {
		return foodBank;
	}
	public void setFoodBank(FoodBank foodBank) {
		this.foodBank = foodBank;
	}
	public Seeker getSeeker() {
		return seeker;
	}
	public void setSeeker(Seeker seeker) {
		this.seeker = seeker;
	}
	public ResponseTemplateVO(FoodBank foodBank, Seeker seeker) {
		super();
		this.foodBank = foodBank;
		this.seeker = seeker;
	}
	
	public ResponseTemplateVO() {
		
	}

}
