package com.example.demo.service;

import java.util.List;

import com.example.demo.VO.ResponseTemplateVO;
import com.example.demo.entity.Seeker;



public interface SeekerService {
	
	List<Seeker> getSeekers();
	
	Seeker saveSeeker(Seeker seeker);
	
	Seeker getSingleSeeker(long id);
	
	void deleteSeeker(long id);
	
	Seeker updateSeeker(Seeker seeker);

	ResponseTemplateVO getSeekerWithFoodBank(Long seekerId);

}